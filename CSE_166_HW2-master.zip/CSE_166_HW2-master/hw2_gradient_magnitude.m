I = imread('circuit.tif');
gradientMagnitude(I);

