#include "window.h"
using namespace std;

const char* window_title = "GLFW Starter Project";
//Cube * cube;
bool static drag = false;
bool static save = false;
bool static circleRotate = false;
bool static scrolling = false;
bool static dirControl = false;
bool static pointControl = false;
bool static spotControl = false;
bool static spotScale = false;
bool static pointScale = false;
//initial the value;
bool static initial = false;
bool static spotinitial = false;
bool static mouseMove = false;
//wider for the spotlight
bool static wider = false;
bool static widerSave = false;
//sharper for the spotligha
//bool static sharper;
int mod = 0;
int texture = 1;
double mousex, mousey;
double posx, posy;
double posz = 0;
double cutoff = glm::cos(glm::radians(12.5f));
double outercutoff = glm::cos(glm::radians(13.0f));
glm::vec3 before, after;
glm::vec3 initialPos = {0.0f, 0.0f, 5.0f};
glm::vec3 initialSpot = {0.0f, 0.0f, 5.0f};
glm::vec3 pointLightPos;
OBJObject * bunny;
OBJObject * dragon;
OBJObject * bear;
//OBJObject * cube;
OBJObject * current;


GLint shaderProgram;

// Default camera parameters
glm::vec3 cam_pos(0.0f, 0.0f, 20.0f);		// e  | Position of camera
glm::vec3 cam_look_at(0.0f, 0.0f, 0.0f);	// d  | This is where the camera looks at
glm::vec3 cam_up(0.0f, 1.0f, 0.0f);			// up | What orientation "up" is

int Window::width;
int Window::height;

glm::mat4 Window::P;
glm::mat4 Window::V;

void Window::initialize_objects()
{
    //cube = new Cube();
    bunny = new OBJObject("/Users/paulszh/CODE/bunny.obj");
    dragon = new OBJObject("/Users/paulszh/CODE/dragon.obj");
    bear = new OBJObject("/Users/paulszh/CODE/bear.obj");
    //cube = new OBJObject("/Users/paulszh/CODE/cube.obj");
    current = bunny;
    
    // Load the shader program. Similar to the .obj objects, different platforms expect a different directory for files
#ifdef _WIN32 // Windows (both 32 and 64 bit versions)
    shaderProgram = LoadShaders("../shader.vert", "../shader.frag");
#else // Not windows
    shaderProgram = LoadShaders("shader.vert", "shader.frag");
#endif
}

void Window::clean_up()
{
    delete(bunny);
    delete(bear);
    delete(dragon);
    //delete(cube);
    glDeleteProgram(shaderProgram);
}

GLFWwindow* Window::create_window(int width, int height)
{
    
    // Initialize GLFW
    if (!glfwInit())
    {
        fprintf(stderr, "Failed to initialize GLFW\n");
        return NULL;
    }
    
    // 4x antialiasing
    glfwWindowHint(GLFW_SAMPLES, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
    
    // Create the GLFW window
    GLFWwindow* window = glfwCreateWindow(width, height, window_title, NULL, NULL);
    
    // Check if the window could not be created
    if (!window)
    {
        fprintf(stderr, "Failed to open GLFW window.\n");
        glfwTerminate();
        return NULL;
    }
    
    // Make the context of the window
    glfwMakeContextCurrent(window);
    
    // Set swap interval to 1
    glfwSwapInterval(1);
    
    // Get the width and height of the framebuffer to properly resize the window
    glfwGetFramebufferSize(window, &width, &height);
    // Call the resize callback to make sure things get drawn immediately
    Window::resize_callback(window, width, height);
    
    return window;
}

void Window::resize_callback(GLFWwindow* window, int width, int height)
{
    Window::width = width;
    Window::height = height;
    // Set the viewport size
    glViewport(0, 0, width, height);
    
    if (height > 0)
    {
        P = glm::perspective(45.0f, (float)width / (float)height, 0.1f, 1000.0f);
        V = glm::lookAt(cam_pos, cam_look_at, cam_up);
    }
}

void Window::idle_callback()
{
    // Call the update function the cube
    //cube->update();
    //current->update();
}

void Window::display_callback(GLFWwindow* window)
{
    // Clear the color and depth buffers
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    // Use the shader of programID
    glUseProgram(shaderProgram);
    
    // Render the cube
    //cube->draw(shaderProgram);
    if(mod == 0){
        current->draw(shaderProgram, mod, texture, 0, 0, 0, 0 , 0);
    }
    else if(mod == 1){
        current->draw(shaderProgram, mod, texture, posx, posy, 0, 0, 0);
    }
    else if(mod == 2){
        //cout << "posz" << posz << endl;
        if(initial){
            current->draw(shaderProgram, mod, texture, initialPos.x, initialPos.y, initialPos.z, 0 , 0);
            pointLightPos = initialPos;
        }
        else{
            
            //cout << "enter else" << endl;
            if(pointControl){
                //mouseMove = false;
            }
            else if(pointScale){
                cout << "enter" << endl;
                //pointScale = false;

            }
            current->draw(shaderProgram, mod, texture, pointLightPos.x, pointLightPos.y, pointLightPos.z, 0 , 0);
            
        }
    }
    else if(mod == 3){
        if(spotinitial){
            posx = 0.0f;
            posy = 0.0f;
            posz = 5.0f;
        }
        current->draw(shaderProgram, mod, texture, posx, posy, posz, cutoff, outercutoff);
    }
    
    // Gets events, including input such as keyboard and mouse or window resizing
    glfwPollEvents();
    // Swap buffers
    glfwSwapBuffers(window);
}
void Window::mouse_button_callback(GLFWwindow* window, int button, int action, int mods){
    
    if(action == GLFW_PRESS){
        //for mouse control
        if(mod == 0){
            if (button == GLFW_MOUSE_BUTTON_RIGHT){
                cout << "The right button is pressed"<<endl;
                drag = true;
                save = true;
            }
            else if(button == GLFW_MOUSE_BUTTON_LEFT){
                cout << "The left button is pressed" << endl;
                circleRotate = true;
                save = false;
                //glfwGetCursorPos(window, &posx, &posy);
                glfwGetCursorPos(window, &mousex, &mousey);
                //before = current->trackBallMapping((float)posx, (float)posy, Window::width, Window::height);
                before = current->trackBallMapping((float)mousex, (float)mousey, Window::width, Window::height);
            }
        }
        //for direct light control
        else if(mod == 1){
            if(button == GLFW_MOUSE_BUTTON_LEFT){
                dirControl = true;
            }
            
        }
        else if(mod == 2){
            if(button == GLFW_MOUSE_BUTTON_LEFT){
                pointControl = true;
                initial = false;
                glfwGetCursorPos(window, &mousex, &mousey);
                before = current->trackBallMapping((float)mousex, (float)mousey, Window::width, Window::height);
            }
        }
        else if(mod == 3){
            if(button == GLFW_MOUSE_BUTTON_LEFT){
                spotinitial = false;
                spotControl = true;
                
            }
            if(button == GLFW_MOUSE_BUTTON_RIGHT){
                wider = true;
                widerSave = true;
                //glfwGetCursorPos(window, &mousex, &mousey);
                
            }
        }
    }
    
    else if(action == GLFW_RELEASE){
        cout << "Release the key" << endl;
        drag = false;
        circleRotate = false;
        dirControl = false;
        pointScale = false;
        //Set every thing to false
        //initial = true;
        spotControl = false;
        pointControl = false;
        dirControl = false;
        wider = false;
        mouseMove = false;
        
        
        
    }
    
}

void Window::cursor_pos_callback(GLFWwindow* window, double xpos, double ypos){
    
    // The cursor entered the client area of the window
    //cout << "( " << xpos << ","<< ypos << ")" << endl;
    if(mod == 0){
        if(drag){
            //do some translation
            if(save){
                //posx = xpos;
                mousex = xpos;
                //posy = ypos;
                mousey = ypos;
                //cout << "initial position" << "( " << posx << ","<< posy << ")" << endl;
                save = false;
            }
            else{
                //current->moveByMourse( (xpos - posx)/10, -(ypos - posy)/10);
                current->moveByMourse( (xpos - mousex)/10, -(ypos - mousey)/10);
                save = true;
            }
        }
        else if(circleRotate){
            
            after = current->trackBallMapping(xpos, ypos, Window::width, Window::height);
            glm:: vec3 moveDirection = after - before;
            float velocity = glm::length(moveDirection);
            glm::vec3 crossProduct = cross(before, after);
            
            if(velocity > 0.00001){
                float angle = velocity;
                current->rotateInCircle(crossProduct, angle);
                before = after;
            }
            
            
        }
    }
    else if(mod == 1){
        if(dirControl){
            glfwGetCursorPos(window, &posx, &posy);
        }
    }
    //for pointLight control
    else if(mod == 2){
        if(pointControl){
            before = current->trackBallMapping(xpos, ypos, Window::width, Window::height);
            pointLightPos.x = before.x * 8;
            pointLightPos.y = before.y * 8;
            pointLightPos.z = before.z * 8;
            
            cout << pointLightPos. x << " "<< pointLightPos.y << " " <<  pointLightPos.z << endl;
            //glm:: vec3 moveDirection = after - before;
            //float velocity = glm::length(moveDirection);
            //glm::vec3 crossProduct = cross(before, after);
            
            /*if(velocity > 0.00001){
                //float angle = velocity;
                glm::vec4 temp = current->rotatePointLight(crossProduct);
                cout << temp. x << " "<< temp.y << " " <<  temp.z << endl;
                pointLightPos.x = temp.x;
                pointLightPos.y = temp.y;
                pointLightPos.z = temp.z;
                before = after;
                mouseMove = true;
            }*/
        }
    }
    else if(mod == 3){
        if(spotControl){
            before = current->trackBallMapping(xpos, ypos, Window::width, Window::height);
            posx = before.x * 6;
            posy = before.y * 6;
            posz = before.z * 6;
            
            //cout << posx << " "<< posy << " " <<  posz << endl;
            
        }
        if(wider == true){
            
            //do some translation
            if(widerSave){
                //posx = xpos;
                mousex = xpos;
                //posy = ypos;
                mousey = ypos;
                //cout << "initial position" << "( " << posx << ","<< posy << ")" << endl;
                widerSave = false;
            }
            else{
                //current->moveByMourse( (xpos - posx)/10, -(ypos - posy)/10);
                if(ypos - mousey > 0){
                    if(cutoff < glm::cos(glm::radians(12.5f)) + 20 * 0.005){
                        cutoff+= 0.005;
                        outercutoff += 0.005;
                    }
                    
                }
                else if(ypos - mousey < 0){
                    if(cutoff > outercutoff){
                        cutoff-=0.005;
                        outercutoff -= 0.005;
                    }
                    
                }
                widerSave = true;
            }
            
        }
        
    }
    
}

void Window::scroll_callback(GLFWwindow* window, double xoffset, double yoffset){
    if(mod == 0){
        scrolling = true;
        if(scrolling && yoffset > 0){
            if(yoffset > 0.2){
                current->moveInto();
                scrolling = false;
            }
        }
        else if(scrolling && yoffset < 0){
            if(yoffset < -0.2){
                current->moveOut();
                scrolling = false;
            }
        }
    }
    else if(mod == 2){
        cout << "enter control" << endl;
        pointScale = true;
        initial= false;
        if(pointScale && yoffset > 0){
            if(yoffset > 0.02){
                //cout << yoffset << endl;
                //cout << "pointLight control"<< endl;
                //glfwGetCursorPos(window, &posx, &posy);
                cout<< pointLightPos.x << " " << pointLightPos.y << " " << pointLightPos.z << endl;
                //pointLightPos.x = pointLightPos.x * 1.1;
                //pointLightPos.y = pointLightPos.y * 1.1;
                pointLightPos.z = pointLightPos.z * 1.1;
                //pointScale = false;
                
            }
            
        }
        else if(pointScale && yoffset <0){
            if(yoffset < -0.02){
                //glfwGetCursorPos(window, &posx, &posy);
                cout<< pointLightPos.x << " " << pointLightPos.y << " " << pointLightPos.z << endl;
                //pointLightPos.x = pointLightPos.x /1.1;
                //pointLightPos.y = pointLightPos.y / 1.1;
                pointLightPos.z = pointLightPos.z / 1.1;
                //pointScale = false;
            }
            
        }
    }
    else if(mod == 3){
        spotScale = true;
        spotinitial = false;
        if(spotScale && yoffset > 0){
            if(yoffset > 0.02){
                //cout << yoffset << endl;
                //cout << "pointLight control"<< endl;
                //glfwGetCursorPos(window, &posx, &posy);
                posx = posx * 1.1;
                posy = posy * 1.1;
                posz = posz * 1.1;
                //pointScale = false;
                
            }
            
        }
        else if(spotScale && yoffset <0){
            if(yoffset < -0.02){
                //glfwGetCursorPos(window, &posx, &posy);
                posx = posx / 1.1;
                posy = posy / 1.1;
                posz = posz / 1.1;
                //pointScale = false;
            }
            
        }
        
    }
    
    
}


void Window::key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    // Check for a key press
    if (action == GLFW_PRESS)
    {
        // Check if escape was pressed
        if (key == GLFW_KEY_ESCAPE)
        {
            // Close the window. This causes the program to also terminate.
            glfwSetWindowShouldClose(window, GL_TRUE);
        }
        
        if (key == GLFW_KEY_F1){
            texture = 1;
            current = bunny;
            cout << "bunny is selected" << endl;
        }
        else if (key == GLFW_KEY_F2){
            //draw the dragon
            texture = 2;
            current = dragon;
            cout << "dragon is selected" << endl;
        }
        else if (key == GLFW_KEY_F3){
            //draw the dragon
            texture = 3;
            cout << "bear is selected" << endl;
            current = bear;
        }
        
        if( key == GLFW_KEY_1){
            cout << "Enter directed Light controller" << endl;
            mod = 1;
        }
        else if( key == GLFW_KEY_2){
            cout << "Enter point Light controller" << endl;
            mod = 2;
            //need to pass some initial position;
            initial = true;
        }
        else if( key == GLFW_KEY_3){
            cout << "Enter spot Light controller" << endl;
            spotinitial = true;
            mod = 3;
            
        }
        //blur and sharper for spotlight
        if(key == GLFW_KEY_E && mods == 0){
            if(mod ==3){
                if(outercutoff < cutoff){
                    outercutoff += 0.05;
                }
            }
            
        }
        else if(key == GLFW_KEY_E && mods == 1){
            if(mod == 3){
                if(outercutoff > 0){
                    outercutoff -= 0.05;
                }
            }
            
        }
        
        
        
        else if(key == GLFW_KEY_0){
            cout << "Go back to the mouse controll mode" << endl;
            mod = 0;
        }
        
        if (key == GLFW_KEY_Z && mods == 0){
            current->moveInto();
        }
        //uppercase z is pressed, move out of the screen
        else if (key == GLFW_KEY_Z && mods == 1){
            current->moveOut();
        }
        else if (key == GLFW_KEY_S && mods == 0){
            cout << "s is pressed"<< endl;
            current->scaleDown();
        }
        else if (key == GLFW_KEY_S && mods == 1){
            cout << "s is pressed"<< endl;
            current->scaleUp();
        }
        else if (key == GLFW_KEY_X && mods == 0){
            current->moveLeft();
            
        }
        //uppercase x is pressed move Right
        else if (key == GLFW_KEY_X && mods == 1){
            current->moveRight();
            
        }
        else if (key == GLFW_KEY_R && mods == 0){
            //cout << "enter" << endl;
            current->resetOBJ();
        }
        
        
        
        
        
        
    }
}