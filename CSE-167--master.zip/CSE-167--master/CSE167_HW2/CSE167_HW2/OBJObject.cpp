#include "OBJObject.h"
#include <stdio.h>
#include <iostream>
#include <fstream>
using namespace std;



struct Color    // generic color class
{
    float r, g, b;  // red, green, blue
};
OBJObject::OBJObject(const char *filepath)
{
    this->toWorld = glm::mat4(1.0f);
    parse(filepath);
    resetWorld = toWorld;
    this->angle = 0.0f;
    
    // Create buffers/arrays
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &EBO);
    glGenBuffers(1, &NORMAL);
    
    // Bind the Vertex Array Object first, then bind and set vertex buffer(s) and attribute pointer(s).
    glBindVertexArray(VAO);
    
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices[0]) * vertices.size(), &vertices[0], GL_STATIC_DRAW);
    
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices[0]) * indices.size(), &indices[0], GL_STATIC_DRAW);
    
    
    glVertexAttribPointer(0,// This first parameter x should be the same as the number passed into the line "layout (location = x)" in the vertex shader. In this case, it's 0. Valid values are 0 to GL_MAX_UNIFORM_LOCATIONS.
                          3, // This second line tells us how any components there are per vertex. In this case, it's 3 (we have an x, y, and z component)
                          GL_FLOAT, // What type these components are
                          GL_FALSE, // GL_TRUE means the values should be normalized. GL_FALSE means they shouldn't
                          3 * sizeof(GLfloat), // Offset between consecutive vertex attributes. Since each of our vertices have 3 floats, they should have the size of 3 floats in between
                          (GLvoid*)0); // Offset of the first vertex's component. In our case it's 0 since we don't pad the vertices array with anything.
    
    glEnableVertexAttribArray(0);
    
    
    glBindBuffer(GL_ARRAY_BUFFER, 0); // Note that this is allowed, the call to glVertexAttribPointer registered VBO as the currently bound vertex buffer object so afterwards we can safely unbind
    
    //glBindVertexArray(0); // Unbind VAO (it's always a good thing to unbind any buffer/array to prevent strange bugs), remember: do NOT unbind the EBO, keep it bound to this VAO
    glBindBuffer(GL_ARRAY_BUFFER, NORMAL);
    glBufferData(GL_ARRAY_BUFFER, sizeof(normals[0]) * normals.size(), &normals[0], GL_STATIC_DRAW);
    glEnableVertexAttribArray(1);
    
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    glBindBuffer(GL_ARRAY_BUFFER, 0); // Note that this is allowed, the call to glVertexAttribPointer registered VBO as the currently bound vertex buffer object so afterwards we can safely unbind
    
    glBindVertexArray(0);
    
    
}
void OBJObject::parse(const char *filepath)
{
    
    //TODO parse the OBJ file
    // Populate the face indices, vertices, and normals vectors with the OBJ Object data
    FILE * file = fopen(filepath, "rb");
    if(file == NULL){
        cout << "The file cannot be open" << endl;
    }
    int c1, c2;
    float x, y, z, r, g, b;
    GLint t_1, t_2, t_3, t_4, t_5, t_6;
    //float x, y, z;
    glm:: vec3 vec;
    float minX = INFINITY;
    float minY = INFINITY;
    float minZ = INFINITY;
    float maxX = -INFINITY;
    float maxY = -INFINITY;
    float maxZ = -INFINITY;
    //parse find the min and max
    while(1){
        c1 = fgetc(file);
        if(c1 == '\n'){
            continue;
        }
        c2 = fgetc(file);
        if(c1 == EOF || c2 == EOF){
            cout << "Reach the end of the file" << endl;
            fclose(file);
            break;
        }
        if((c1 == 'v') && (c2 == ' ')){
            //cout << "v" << vec.x << vec.y << vec.z << endl;
            fscanf(file, " %f %f %f %f %f %f", &x, &y, &z, &r, &g, &b);
            if(x < minX){
                minX = x;
            }
            if(x >= maxX){
                maxX = x;
            }
            if(y < minY){
                minY = y;
            }
            if(y >= maxY){
                maxY = y;
            }
            if(z < minZ){
                minZ = z;
            }
            if(z >= maxZ){
                maxZ = z;
            }
        }
    }
    //calculate the average value
    float avgx = (minX + maxX)/2.0;
    float avgy = (minY + maxY)/2.0;
    float avgz = (minZ + maxZ)/2.0;
    cout << "avgx " << avgx << "avgy" << avgy << "avgz" << avgz;
    
    file = fopen(filepath, "rb");
    while(1){
        c1 = fgetc(file);
        if(c1 == '\n'){
            continue;
        }
        c2 = fgetc(file);
        if(c1 == EOF || c2 == EOF){
            cout << "Reach the end of the file" << endl;
            cout << "The size of vertices" << vertices.size() << endl;
            cout << "The size of normals" << normals.size() << endl;
            cout << "The size of indices" << indices.size() << endl;
            
            fclose(file);
            break;
        }
        
        if((c1 == 'v') && (c2 == ' ')){
            //cout << "v" << vec.x << vec.y << vec.z << endl;
            fscanf(file, " %f %f %f %f %f %f", &x, &y, &z, &r, &g, &b);
            float max = fmax(maxX-minX, fmax(maxY - minY, maxZ - minZ));
            vec.x = (x - avgx)/max;
            vec.y = (y - avgy)/max;
            vec.z = (z - avgz)/max;
            vertices.push_back(vec);
            
        }
        
        else if((c1 =='v') && (c2 == 'n')){
            fscanf(file, " %f %f %f", &x, &y, &z);
            vec.x = x;
            vec.y = y;
            vec.z = z;
            glm::vec3 norm = normalize(vec);
            norm.x = (norm.x+1.0)/2.0;
            norm.y = (norm.y+1.0)/2.0;
            norm.z = (norm.z+1.0)/2.0;
            normals.push_back(norm);
            
        }
        
        else if((c1 == 'f') && (c2 == ' ')){
            //cout << "Enter f" << endl;
            //cout << x <<" "<< y<< " "<< z << endl;
            fscanf(file, " %u//%u %u//%u %u//%u", &t_1 ,&t_2, &t_3, &t_4, &t_5, &t_6);
            indices.push_back(t_1-1);
            indices.push_back(t_3-1);
            indices.push_back(t_5-1);
        }
        
        
        
    }
    
}

glm::mat4 OBJObject:: getWorld(){
    return toWorld;
}

vector<glm::vec3> OBJObject:: getVertices(){
    return vertices;
}


vector<glm::vec3> OBJObject:: getNormals(){
    return normals;
    
}

void OBJObject::update(){
    spin(1.0f);
}

void OBJObject::spin(float deg){
    
    this->angle += deg;
    if (this->angle > 360.0f || this->angle < -360.0f) this->angle = 0.0f;
    // This creates the matrix to rotate the cube
    this->toWorld = glm::rotate(this->toWorld, deg / 180.0f * glm::pi<float>(), glm::vec3(0.0f, 1.0f, 0.0f));
    
}

/*void Cube::update()
 {
 spin(1.0f);
 }
 
 void Cube::spin(float deg)
 {
 this->angle += deg;
 if (this->angle > 360.0f || this->angle < -360.0f) this->angle = 0.0f;
 // This creates the matrix to rotate the cube. You'd probably want to change this with the more favorable way of performing a spin
 // which you did in the previous project.
 this->toWorld = glm::rotate(glm::mat4(1.0f), this->angle / 180.0f * glm::pi<float>(), glm::vec3(0.0f, 1.0f, 0.0f));
 }*/

void OBJObject:: moveLeft(){
    this->toWorld = glm::translate(glm:: mat4(), glm::vec3 (-1.0f, 0.0f, 0.0f)) * this->toWorld;
    
}

void OBJObject:: moveRight(){
    this->toWorld = glm::translate(glm:: mat4(), glm::vec3 (1.0f, 0.0f, 0.0f)) * this->toWorld;
    
}
void OBJObject:: moveUp(){
    //glm:: vec3 up()
    this->toWorld = glm::translate(glm:: mat4(), glm::vec3 (0.0f, 1.0f, 0.0f)) * this->toWorld;
}

void OBJObject:: moveDown(){
    this->toWorld = glm::translate(glm:: mat4(), glm::vec3 (0.0f, -1.0f, 0.0f)) * this->toWorld;
    
}

void OBJObject::moveInto(){
    this->toWorld = glm::translate(glm:: mat4(), glm::vec3 (0.0f, 0.0f, 1.0f)) * this->toWorld;
    
}

void OBJObject::moveOut(){
    this->toWorld = glm::translate(glm:: mat4(), glm::vec3 (0.0f, 0.0f, -1.0f)) * this->toWorld;
    
}

void OBJObject::scaleUp(){
    glm::mat4 temp = glm::scale(glm::mat4(1.0f), glm::vec3 (2.0f, 2.0f, 2.0f));
    this->toWorld = this->toWorld * temp;
}

void OBJObject::scaleDown(){
    glm::mat4 temp = glm::scale(glm::mat4(1.0f), glm::vec3 (0.5f, 0.5f, 0.5f));
    this->toWorld = this->toWorld * temp;
    
}

void OBJObject::rotateClockWise(){
    glm::mat4 temp = glm::rotate(glm::mat4(), 30.0f/ 180.0f * glm::pi<float>(), glm::vec3(0.0f, 0.0f, 1.0f));
    this->toWorld = temp *this->toWorld;
}

void OBJObject::rotateCounterClockWise(){
    glm::mat4 temp = glm::rotate(glm::mat4(), -30.0f/ 180.0f * glm::pi<float>(), glm::vec3(0.0f, 0.0f, 1.0f));
    this->toWorld = temp *this->toWorld;
}
void OBJObject::moveByMourse(float x, float y){
    this->toWorld = glm::translate(glm:: mat4(), glm::vec3 (x, y, 0.0f)) * this->toWorld;
}
void OBJObject::rotateInCircle(glm::vec3 v, float angle){
    glm::mat4 temp = glm::rotate(glm::mat4(),  angle , glm::vec3(v.x, v.y, v.z));
    this->toWorld = temp * this->toWorld;
}

glm::vec4 OBJObject::rotatePointLight(glm::vec3 v){
    glm::mat4 temp = glm::rotate(glm::mat4(), 20.0f , glm::vec3(v.x, v.y, v.z));
    glm::vec4 rot= temp * glm::vec4(v,0.0f);
    //cout << rot.x << rot.y << rot.z << endl;
    return rot;
    
}

glm::vec3 OBJObject::trackBallMapping(float x, float y, int width, int height){
    glm::vec3 v;
    float d;
    
    v.x = ( x * 2.0 - width)/width;
    v.y = ( height - 2.0 * y)/height;
    v.z = 0.0;
    
    d = glm::length(v);
    d = (d < 1.0) ? d : 1.0;
    v.z = sqrtf(1.001 - d * d);
    v = normalize(v);
    
    return v;
}

void OBJObject::resetOBJ(){
    toWorld = resetWorld;
}



void OBJObject::draw()
{
    glMatrixMode(GL_MODELVIEW);
    
    // Push a save state onto the matrix stack, and multiply in the toWorld matrix
    glPushMatrix();
    glMultMatrixf(&(toWorld[0][0]));
    //cout << vertices.size() << endl;
    //cout << normals.size() << endl;
    //glColor3f(0.9f, 0.17f, 0.31f);
    
    glBegin(GL_POINTS);
    // Loop through all the vertices of this OBJ Object and render them
    glm:: vec3 color;
    float x,y,z;
    for (unsigned int i = 0; i < vertices.size(); ++i)
    {
        color = normalize(normals[i]);
        x = (color.x+1.0)/2.0;
        y = (color.y+1.0)/2.0;
        z = (color.z+1.0)/2.0;
        //cout <<  x << y << z << endl;
        glColor3f(x, y, z);
        glVertex3f(vertices[i].x, vertices[i].y, vertices[i].z);
        //glColor3f(color.x, color.y, color.z);
        
    }
    
    glEnd();
    
    // Pop the save state off the matrix stack
    // This will undo the multiply we did earlier
    glPopMatrix();
}


void OBJObject::draw(GLuint shaderProgram, int mod, int texture, float x, float y, float z, float cutoff, float outercutoff)
{
    // Calculate combination of the model (toWorld), view (camera inverse), and perspective matrices
    //glm::mat4 MVP = Window::P * Window::V * toWorld;
    // We need to calculate this because as of GLSL version 1.40 (OpenGL 3.1, released March 2009), gl_ModelViewProjectionMatrix has been
    // removed from the language. The user is expected to supply this matrix to the shader when using modern OpenGL.
    //GLuint MatrixID = glGetUniformLocation(shaderProgram, "MVP");
    GLuint ProjectionID = glGetUniformLocation(shaderProgram, "projection");
    GLuint ModelID = glGetUniformLocation(shaderProgram, "model");
    GLuint ViewID = glGetUniformLocation(shaderProgram, "view");
    GLuint viewposLoc = glGetUniformLocation(shaderProgram, "viewPos");
    GLuint lightMode = glGetUniformLocation(shaderProgram, "mode");
    glm::vec3 vector = {0.0f, 0.0f, 20.0f};
    glm::uvec3 mode = {mod, 0, 0};
    glClearColor(0.75f, 0.52f, 0.3f, 1.0f);
    
    //glUniformMatrix4fv(MatrixID, 1, GL_FALSE, &MVP[0][0]);
    glUniformMatrix4fv(ProjectionID, 1, GL_FALSE, &Window::P[0][0]);
    glUniformMatrix4fv(ModelID, 1, GL_FALSE, &toWorld[0][0]);
    glUniformMatrix4fv(ViewID, 1, GL_FALSE, &Window::V[0][0]);
    glUniform3f(viewposLoc, vector.x, vector.y, vector.z);
    glUniform3f(lightMode, mode.x, mode.y, mode.z);
    
    if(texture == 1){
        glUniform1f(glGetUniformLocation(shaderProgram, "material.shininess"), 1.0f);
        
        glUniform3f(glGetUniformLocation(shaderProgram, "material.ambient"), 0.1f, 0.1f, 0.4f);
        
        glUniform3f(glGetUniformLocation(shaderProgram, "material.diffuse"), 0.6f, 0.1f, 0.5f);
        
        glUniform3f(glGetUniformLocation(shaderProgram, "material.specular"), 1.0f, 1.0f, 1.0f);
    }
    else if(texture == 2){
        glUniform1f(glGetUniformLocation(shaderProgram, "material.shininess"), 0.5f);
        
        glUniform3f(glGetUniformLocation(shaderProgram, "material.ambient"), 0.1f, 0.1f, 0.4f);
        
        glUniform3f(glGetUniformLocation(shaderProgram, "material.diffuse"), 0.8f, 0.7f, 0.9f);
        
        glUniform3f(glGetUniformLocation(shaderProgram, "material.specular"), 0.3f, 0.4f, 1.0f);
        
    }
    else if(texture == 3){
        glUniform1f(glGetUniformLocation(shaderProgram, "material.shininess"), 4.0f);
        
        glUniform3f(glGetUniformLocation(shaderProgram, "material.ambient"), 0.1f, 0.5f, 0.4f);
        
        glUniform3f(glGetUniformLocation(shaderProgram, "material.diffuse"), 0.2f, 0.3f, 0.2f);
        
        glUniform3f(glGetUniformLocation(shaderProgram, "material.specular"), 4.0f, 5.0f, 7.0f);
        
    }
    
    if(mod == 0){
        glUniform3f(glGetUniformLocation(shaderProgram, "dirLight.direction"), -0.2f, -1.0f, -0.3f);
        
        glUniform3f(glGetUniformLocation(shaderProgram, "dirLight.ambient"), 0.05f, 0.05f, 0.1f);
        
        glUniform3f(glGetUniformLocation(shaderProgram, "dirLight.diffuse"), 0.2f, 0.2f, 0.7);
        
        glUniform3f(glGetUniformLocation(shaderProgram, "dirLight.specular"), 0.7f, 0.7f, 0.7f);
    }
    //direct light
    else if(mod == 1){
        glUniform3f(glGetUniformLocation(shaderProgram, "dirLight.direction"), -x, -y, -0.3f);
        
        glUniform3f(glGetUniformLocation(shaderProgram, "dirLight.ambient"), 0.05f, 0.05f, 0.1f);
        
        glUniform3f(glGetUniformLocation(shaderProgram, "dirLight.diffuse"), 0.2f, 0.2f, 0.7);
        
        glUniform3f(glGetUniformLocation(shaderProgram, "dirLight.specular"), 0.7f, 0.7f, 0.7f);
        
        
    }
    
    else if(mod == 2){
        glm::vec3 pointLightColors[] = {
            glm::vec3(1.0f, 0.6f, 0.0f),
            glm::vec3(1.0f, 0.0f, 0.0f),
            glm::vec3(1.0f, 1.0, 0.0),
            glm::vec3(0.2f, 0.2f, 1.0f)
        };
        glm::vec3 pointLightPosition = {x, y, z};
        glUniform3f(glGetUniformLocation(shaderProgram, "pointLights[0].position"), pointLightPosition.x, pointLightPosition.y, pointLightPosition.z);
        
        glUniform3f(glGetUniformLocation(shaderProgram, "pointLights[0].ambient"), pointLightColors[0].x * 0.1,  pointLightColors[0].y * 0.1,  pointLightColors[0].z * 0.1);
        
        glUniform3f(glGetUniformLocation(shaderProgram, "pointLights[0].diffuse"), pointLightColors[0].x,  pointLightColors[0].y,  pointLightColors[0].z);
        
        glUniform3f(glGetUniformLocation(shaderProgram, "pointLights[0].specular"), pointLightColors[0].x,  pointLightColors[0].y,  pointLightColors[0].z);
        
        glUniform1f(glGetUniformLocation(shaderProgram, "pointLights[0].constant"), 1.0f);
        
        glUniform1f(glGetUniformLocation(shaderProgram, "pointLights[0].linear"), 0.09);
        
        glUniform1f(glGetUniformLocation(shaderProgram, "pointLights[0].quadratic"), 0.032);
    }
    else if(mod == 3){
        
        glUniform3f(glGetUniformLocation(shaderProgram, "spotLight.position"), x, y, z);
        
        glUniform3f(glGetUniformLocation(shaderProgram, "spotLight.direction"), x, y, -z);
        
        glUniform3f(glGetUniformLocation(shaderProgram, "spotLight.ambient"), 0.0f, 0.0f, 0.0f);
        
        glUniform3f(glGetUniformLocation(shaderProgram, "spotLight.diffuse"), 0.8f, 0.8f, 0.0f);
        
        glUniform3f(glGetUniformLocation(shaderProgram, "spotLight.specular"), 0.8f, 0.8f, 0.0f);
        
        glUniform1f(glGetUniformLocation(shaderProgram, "spotLight.constant"), 1.0f);
        
        glUniform1f(glGetUniformLocation(shaderProgram, "spotLight.linear"), 0.09);
        
        glUniform1f(glGetUniformLocation(shaderProgram, "spotLight.quadratic"), 0.032);
        
        glUniform1f(glGetUniformLocation(shaderProgram, "spotLight.cutOff"), cutoff);
        
        glUniform1f(glGetUniformLocation(shaderProgram, "spotLight.outerCutOff"), outercutoff);
    }
    
    
    //glUniform
    glBindVertexArray(VAO);
    glDrawElements(GL_TRIANGLES, (GLint)indices.size(), GL_UNSIGNED_INT, 0);
    glBindVertexArray(0);
}

void OBJObject::rasterize(){
    
    float x1 = (float)window_width;
    float y1 = (float)window_height;
    
    glm::vec3 up = glm::vec3(0.0f, 1.0f, 0.0f);
    glm::vec3 e = glm::vec3(0.0f, 0.0f, 20.0f);
    glm::vec3 d = glm::vec3(0.0f, 0.0f, 0.0f);
    
    glm::mat4x4 image;
    image[0] = glm::vec4((x1) / 2.0, 0, 0, 0);
    image[1] = glm::vec4(0, (y1) / 2.0, 0, 0);
    image[2] = glm::vec4(0, 0, 1.0 / 2.0, 0);
    image[3] = glm::vec4((x1) / 2.0, (y1) / 2.0, 1.0/ 2.0, 1.0);
    
    glm::mat4x4 cameraInverse = glm::lookAt(e, d, up);
    glm::mat4x4 perspective = glm::perspective(glm::radians(60.0f), (float)window_width / (float)window_height, 1.0f, 1000.0f);
    glm:: vec3 color;
    float x,y,z;
    
    for (unsigned int i = 0; i < vertices.size(); ++i)
    {
        glm::vec4 p = glm::vec4 (vertices[i].x, vertices[i].y, vertices[i].z, 1.0f);
        glm::vec4 result = image * perspective * cameraInverse * toWorld * p;
        color = normalize(normals[i]);
        x = (color.x+1.0)/2.0;
        y = (color.y+1.0)/2.0;
        z = (color.z+1.0)/2.0;
        //cout << "Size:"<< pointSize << endl;
        for(int k = 0; k < pointSize; k++){
            for(int j = 0; j < pointSize; j++){
                drawPoint((int)(result.x / result.z) + k , (int)(result.y / result.z) + j , x, y, z);
            }
        }
    }
    
    
    
    
}

void OBJObject:: drawPoint(int x, int y, float r, float g, float b)
{
    if (x < 0 || x > window_width-1 || y < 0 || y >window_height-1) return;
    int offset = y*window_width * 3 + x * 3;
    pixels[offset] = r;
    pixels[offset + 1] = g;
    pixels[offset + 2] = b;
}


void OBJObject:: clearBuffer()
{
    Color clearColor = { 0.0, 0.0, 0.0 };   // clear color: black
    for (int i = 0; i<window_width*window_height; ++i)
    {
        pixels[i * 3] = clearColor.r;
        pixels[i * 3 + 1] = clearColor.g;
        pixels[i * 3 + 2] = clearColor.b;
    }
}


