#ifndef OBJOBJECT_H
#define OBJOBJECT_H

#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/mat4x4.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <vector>
#include "Window.h"


class OBJObject
{
private:
    std::vector<GLint> indices;
    float angle;
    glm::mat4 toWorld;
    glm:: mat4 resetWorld;
	GLuint VBO, VAO, EBO, NORMAL;
    
    
public:
    void parse(const char* filepath);
    OBJObject(const char* filepath);
    std::vector<glm::vec3> vertices;
    std::vector<glm::vec3> normals;
    int window_height = 480;
    int window_width = 640;
    int pointSize = 1;
    
    
    //bunch of method RENDER with openGL
    void spin(float deg);
    void update();
    void moveUp();
    void moveDown();
    void moveLeft();
    void scaleUp();
    void rotation();
    void scaleDown();
    void moveRight();
    void moveInto();
    void moveOut();
    void rotateClockWise();
    void rotateCounterClockWise();
    void resetOBJ();
    void draw();
    void moveByMourse(float x, float y);
    void rotateInCircle(glm::vec3 v, float angle);
    glm::vec3 trackBallMapping(float x, float y, int width, int height );
    //bunch of method RENDER without openGL
    void rasterize();
    void clearBuffer();
    void drawPoint(int x, int y, float r, float g, float b);
    
    glm:: mat4 getWorld();
    std::vector<glm::vec3> getVertices();
    std::vector<glm::vec3> getNormals();
    float* pixels = new float[window_width * window_height * 3];
    glm::vec4 rotatePointLight(glm::vec3);
    
    //the method created in HW2
    void draw(GLuint shaderProgram, int mod, int texture, float x, float y, float z, float cutoff, float outercutoff);

    
    
    
    
};

#endif