//
//  Rasterizer.h
//  Points Cloud
//
//  Created by paulszh on 4/6/16.
//  Copyright © 2016 pauslzh. All rights reserved.
//

#ifndef Rasterizer_h
#define Rasterizer_h
#include "OBJObject.h"
class Rasterizer{
    
    public:
    glm:: mat4 projection;
    glm:: mat4 model;
    glm:: mat4 camera;
    glm:: mat4 image;
    glm:: mat4 DPC;
    OBJObject * current;
    int window_width = 640;
    int window_height = 480;
    float* pixels = new float[window_width * window_height * 3];
    std::vector<glm::vec3> tempVertices;
    std::vector<glm::vec3> tempNormals;
    Rasterizer();
    Rasterizer(OBJObject * obj);
    void loadData();
    void clearBuffer();
    void rasterize();
    void drawPoint(int x, int y, float r, float g, float b);
    //void resizeCallback(GLFWwindow* window, int width, int height);
    //void keyCallback(GLFWwindow* window, int key, int scancode, int action, int mods);
    //void displayCallback(GLFWwindow* window);
    //void errorCallback(int error, const char* description);
};


#endif /* Rasterizer_h */
