#include <iostream>
#include <math.h>
#include "Rasterizer.h"
#include <vector>
#include <GL/glew.h>
#include <GLFW/glfw3.h>



using namespace std;

struct Color    // generic color class
{
    float r, g, b;  // red, green, blue
};

Rasterizer::Rasterizer(){
    
}

Rasterizer:: Rasterizer(OBJObject * obj){
    //initialize the projection matrix
    projection = glm::perspective(glm::radians(60.0f), (float)window_width/(float)window_height, 1.0f, 1000.0f);
    //initialize the image matrix
    image[0] = glm::vec4((float)window_width/2.0, 0.0f, 0.0f, 0.0f);
    image[1] = glm::vec4(0.0f, (float)window_height/2.0, 0.0f, 0.0f);
    image[2] = glm::vec4(0.0f, 0.0f, 1.0/2.0, 0.0f);
    image[3] = glm::vec4((float)window_width/2.0, (float)window_height/2.0, 1.0/2.0, 1.0f);
    //initialize the camera matrix
    camera = glm:: lookAt(glm:: vec3(0.0f, 0.0f, 3.0f), glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0,1,0));
    model = glm::mat4();
    DPC = camera * image * projection;
    cout << "1" << endl;
    current = obj;
    
}

void Rasterizer:: loadData()
{
    // point cloud parser goes here
}

// Clear frame buffer
void Rasterizer:: clearBuffer()
{
    Color clearColor = { 0.0, 1.0, 0.0 };   // clear color: black
    for (int i = 0; i<window_width*window_height; ++i)
    {
        pixels[i * 3] = clearColor.r;
        pixels[i * 3 + 1] = clearColor.g;
        pixels[i * 3 + 2] = clearColor.b;
    }
}

// Draw a point into the frame buffer
void Rasterizer:: drawPoint(int x, int y, float r, float g, float b)
{
    int offset = y*window_width * 3 + x * 3;
    pixels[offset] = r;
    pixels[offset + 1] = g;
    pixels[offset + 2] = b;
}

void Rasterizer:: rasterize()
{
    
    cout << "2" << endl;
    glm:: vec4 p;
    glm:: vec4 result;
    glm:: vec3 temp;
    tempVertices = current->getVertices();
    tempNormals = current->getNormals();
    
    for(unsigned int i = 0; i < tempVertices.size(); i++){
        temp = (tempVertices)[i];
        p = glm:: vec4(temp.x, temp.y, temp.z, 1.0f);
        p = p * model;
        result = DPC * p;
        result.x = result.x/result.w;
        result.y = result.y/result.w;
        drawPoint(result.x,result.y, (tempNormals)[i].x, (tempNormals)[i].y,(tempNormals)[i].z);
    }
    // Put your main rasterization loop here
    // It should go over the point model and call drawPoint for every point in it
}

// Called whenever the window size changes
/*void Rasterizer:: resizeCallback(GLFWwindow* window, int width, int height)
{
    window_width = width;
    window_height = height;
    delete[] pixels;
    pixels = new float[window_width * window_height * 3];
}


void Rasterizer:: displayCallback(GLFWwindow* window)
{
    Rasterizer:: clearBuffer();
    Rasterizer::rasterize();
    
    // glDrawPixels writes a block of pixels to the framebuffer
    glDrawPixels(window_width, window_height, GL_RGB, GL_FLOAT, pixels);
    
    // Gets events, including input such as keyboard and mouse or window resizing
    glfwPollEvents();
    // Swap buffers
    glfwSwapBuffers(window);
}

void Rasterizer:: errorCallback(int error, const char* description)
{
    // Print error
    fputs(description, stderr);
}*/

/*int main(int argc, char** argv) {
	// Initialize GLFW
	if (!glfwInit())
	{
 fprintf(stderr, "Failed to initialize GLFW\n");
 return -1;
	}
 
	// 4x antialiasing
	glfwWindowHint(GLFW_SAMPLES, 4);
 
	// Create the GLFW window
	GLFWwindow* window = glfwCreateWindow(window_height, window_height, "Rastizer", NULL, NULL);
 
	// Check if the window could not be created
	if (!window)
	{
 fprintf(stderr, "Failed to open GLFW window.\n");
 glfwTerminate();
 return -1;
	}
 
	// Make the context of the window
	glfwMakeContextCurrent(window);
 
	// Set swap interval to 1
	glfwSwapInterval(1);
 
	loadData();
 
	// Set the error callback
	glfwSetErrorCallback(errorCallback);
	// Set the key callback
	glfwSetKeyCallback(window, keyCallback);
	// Set the window resize callback
	glfwSetWindowSizeCallback(window, resizeCallback);
 
	// Loop while GLFW window should stay open
	while (!glfwWindowShouldClose(window))
	{
 // Main render display callback. Rendering of objects is done here.
 displayCallback(window);
	}
 
	// Destroy the window
	glfwDestroyWindow(window);
	// Terminate GLFW
	glfwTerminate();
 
	exit(EXIT_SUCCESS);
 }*/