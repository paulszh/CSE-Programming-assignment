#ifndef OBJOBJECT_H
#define OBJOBJECT_H

#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/mat4x4.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <vector>


class OBJObject
{
private:
    std::vector<unsigned int> indices;
    float angle;
    glm::mat4 toWorld;
    glm:: mat4 resetWorld;
    
    
public:
    void parse(const char* filepath);
    OBJObject(const char* filepath);
    std::vector<glm::vec3> vertices;
    std::vector<glm::vec3> normals;
    int window_height = 480;
    int window_width = 640;
    int pointSize = 1;
    
    
    //bunch of method RENDER with openGL
    void spin(float deg);
    void update();
    void moveUp();
    void moveDown();
    void moveLeft();
    void scaleUp();
    void rotation();
    void scaleDown();
    void moveRight();
    void moveInto();
    void moveOut();
    void rotateClockWise();
    void rotateCounterClockWise();
    void resetOBJ();
    void draw();
    void rasterize();
    void clearBuffer();
    void drawPoint(int x, int y, float r, float g, float b);
    
    glm:: mat4 getWorld();
    std::vector<glm::vec3> getVertices();
    std::vector<glm::vec3> getNormals();
    float* pixels = new float[window_width * window_height * 3];

    
    //bunch of method RENDER without openGL
    
    
    
};

#endif