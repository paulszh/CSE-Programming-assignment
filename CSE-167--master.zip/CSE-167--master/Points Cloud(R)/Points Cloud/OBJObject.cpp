#include "OBJObject.h"
#include <stdio.h>
#include <iostream>
#include <fstream>
using namespace std;



struct Color    // generic color class
{
    float r, g, b;  // red, green, blue
};
OBJObject::OBJObject(const char *filepath)
{
	toWorld = glm::mat4(1.0f);
	parse(filepath);
    resetWorld = toWorld;
    
}

void OBJObject::parse(const char *filepath) 
{
    
	//TODO parse the OBJ file
	// Populate the face indices, vertices, and normals vectors with the OBJ Object data
    FILE * file = fopen(filepath, "rb");
    if(file == NULL){
        cout << "The file cannot be open" << endl;
    }
    int c1, c2;
    float x, y, z, r, g, b;
    //float x, y, z;
    glm:: vec3 vec;
    while(1){
        c1 = fgetc(file);
        c2 = fgetc(file);
        
        if(c1 == EOF || c2 == EOF){
            cout << "Reach the end of the file" << endl;
            cout << "The size of vertices" << vertices.size() << endl;
            cout << "The size of normals" << normals.size() << endl;
            fclose(file);
            break;
        }
        
        if((c1 == 'v') && (c2 == ' ')){
            //cout << "v" << vec.x << vec.y << vec.z << endl;
            fscanf(file, " %f %f %f %f %f %f", &x, &y, &z, &r, &g, &b);
            vec.x = x;
            vec.y = y;
            vec.z = z;
            vertices.push_back(vec);
            
        }
        
        else if((c1 =='v') && (c2 == 'n')){
            fscanf(file, " %f %f %f", &x, &y, &z);
            vec.x = x;
            vec.y = y;
            vec.z = z;
            normals.push_back(vec);
            
        }
        
    }
    //return;

    

}
glm::mat4 OBJObject:: getWorld(){
    return toWorld;
}

vector<glm::vec3> OBJObject:: getVertices(){
    return vertices;
}


vector<glm::vec3> OBJObject:: getNormals(){
    return normals;

}

void OBJObject::update(){
	spin(1.0f);
}

void OBJObject::spin(float deg){
    
    this->angle += deg;
    if (this->angle > 360.0f || this->angle < -360.0f) this->angle = 0.0f;
    // This creates the matrix to rotate the cube
    this->toWorld = glm::rotate(this->toWorld, deg / 180.0f * glm::pi<float>(), glm::vec3(0.0f, 1.0f, 0.0f));

}

void OBJObject:: moveLeft(){
    this->toWorld = glm::translate(glm:: mat4(), glm::vec3 (-1.0f, 0.0f, 0.0f)) * this->toWorld;
    
}

void OBJObject:: moveRight(){
    this->toWorld = glm::translate(glm:: mat4(), glm::vec3 (1.0f, 0.0f, 0.0f)) * this->toWorld;
    
}
void OBJObject:: moveUp(){
    //glm:: vec3 up()
    this->toWorld = glm::translate(glm:: mat4(), glm::vec3 (0.0f, 1.0f, 0.0f)) * this->toWorld;
}

void OBJObject:: moveDown(){
    this->toWorld = glm::translate(glm:: mat4(), glm::vec3 (0.0f, -1.0f, 0.0f)) * this->toWorld;
    
}

void OBJObject::moveInto(){
    this->toWorld = glm::translate(glm:: mat4(), glm::vec3 (0.0f, 0.0f, 1.0f)) * this->toWorld;
    
}

void OBJObject::moveOut(){
    this->toWorld = glm::translate(glm:: mat4(), glm::vec3 (0.0f, 0.0f, -1.0f)) * this->toWorld;
    
}

void OBJObject::scaleUp(){
    glm::mat4 temp = glm::scale(glm::mat4(1.0f), glm::vec3 (2.0f, 2.0f, 2.0f));
    this->toWorld = this->toWorld * temp;
}

void OBJObject::scaleDown(){
    glm::mat4 temp = glm::scale(glm::mat4(1.0f), glm::vec3 (0.5f, 0.5f, 0.5f));
    this->toWorld = this->toWorld * temp;
    
}

void OBJObject::rotateClockWise(){
    glm::mat4 temp = glm::rotate(glm::mat4(), 30.0f/ 180.0f * glm::pi<float>(), glm::vec3(0.0f, 0.0f, 1.0f));
    this->toWorld = temp *this->toWorld;
}

void OBJObject::rotateCounterClockWise(){
    glm::mat4 temp = glm::rotate(glm::mat4(), -30.0f/ 180.0f * glm::pi<float>(), glm::vec3(0.0f, 0.0f, 1.0f));
    this->toWorld = temp *this->toWorld;
}

void OBJObject::resetOBJ(){
    toWorld = resetWorld;
}



void OBJObject::draw() 
{
	glMatrixMode(GL_MODELVIEW);

	// Push a save state onto the matrix stack, and multiply in the toWorld matrix
	glPushMatrix();
	glMultMatrixf(&(toWorld[0][0]));
    //cout << vertices.size() << endl;
    //cout << normals.size() << endl;
    //glColor3f(0.9f, 0.17f, 0.31f);

	glBegin(GL_POINTS);
	// Loop through all the vertices of this OBJ Object and render them
    glm:: vec3 color;
    GLfloat coord[3];
    float x,y,z;
	for (unsigned int i = 0; i < vertices.size(); ++i) {
        color = normalize(normals[i]);
        x = (color.x+1.0)/2.0;
        y = (color.y+1.0)/2.0;
        z = (color.z+1.0)/2.0;
        //cout <<  x << y << z << endl;
        glColor3f(x, y, z);
        coord[0] = vertices[i].x;
        coord[1] = vertices[i].y;
        coord[2] = vertices[i].z;
		glVertex3fv(coord);
        //glColor3f(color.x, color.y, color.z);
        
	}
    
	glEnd();

	// Pop the save state off the matrix stack
	// This will undo the multiply we did earlier
	glPopMatrix();
}

void OBJObject::rasterize(){
    
    float x1 = (float)window_width;
    float y1 = (float)window_height;
    
    glm::vec3 up = glm::vec3(0.0f, 1.0f, 0.0f);
    glm::vec3 e = glm::vec3(0.0f, 0.0f, 20.0f);
    glm::vec3 d = glm::vec3(0.0f, 0.0f, 0.0f);
    
    glm::mat4x4 image;
    image[0] = glm::vec4((x1) / 2.0, 0, 0, 0);
    image[1] = glm::vec4(0, (y1) / 2.0, 0, 0);
    image[2] = glm::vec4(0, 0, 1.0 / 2.0, 0);
    image[3] = glm::vec4((x1) / 2.0, (y1) / 2.0, 1.0/ 2.0, 1.0);
    
    glm::mat4x4 cameraInverse = glm::lookAt(e, d, up);
    glm::mat4x4 perspective = glm::perspective(glm::radians(60.0f), (float)window_width / (float)window_height, 1.0f, 1000.0f);
    glm:: vec3 color;
    float x,y,z;
    
    for (unsigned int i = 0; i < vertices.size(); ++i)
    {
        glm::vec4 p = glm::vec4 (vertices[i].x, vertices[i].y, vertices[i].z, 1.0f);
        glm::vec4 result = image * perspective * cameraInverse * toWorld * p;
        color = normalize(normals[i]);
        x = (color.x+1.0)/2.0;
        y = (color.y+1.0)/2.0;
        z = (color.z+1.0)/2.0;
        //cout << "Size:"<< pointSize << endl;
        for(int k = 0; k < pointSize; k++){
            for(int j = 0; j < pointSize; j++){
                drawPoint((int)(result.x / result.z) + k , (int)(result.y / result.z) + j , x, y, z);
            }
        }
    }


    
    
}

void OBJObject:: drawPoint(int x, int y, float r, float g, float b)
{
    if (x < 0 || x > window_width-1 || y < 0 || y >window_height-1) return;
    int offset = y*window_width * 3 + x * 3;
    pixels[offset] = r;
    pixels[offset + 1] = g;
    pixels[offset + 2] = b;
}


void OBJObject:: clearBuffer()
{
    Color clearColor = { 0.0, 0.0, 0.0 };   // clear color: black
    for (int i = 0; i<window_width*window_height; ++i)
    {
        pixels[i * 3] = clearColor.r;
        pixels[i * 3 + 1] = clearColor.g;
        pixels[i * 3 + 2] = clearColor.b;
    }
}


