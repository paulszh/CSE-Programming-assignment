#include "Window.h"
using namespace std;

const char* window_title = "GLFW Starter Project";
//Cube cube(5.0f);
OBJObject bunny("/Users/paulszh/CODE/bunny.obj");
OBJObject dragon("/Users/paulszh/CODE/dragon.obj");
OBJObject bear("/Users/paulszh/CODE/bear.obj");
OBJObject * current = &bunny;

float size = 1;
static bool switchMode = false;



int Window::width;
int Window::height;
void Window::initialize_objects()
{
}

void Window::clean_up()
{
}

GLFWwindow* Window::create_window(int width, int height)
{
    // Initialize GLFW
    if (!glfwInit())
    {
        fprintf(stderr, "Failed to initialize GLFW\n");
        return NULL;
    }
    
    // 4x antialiasing
    glfwWindowHint(GLFW_SAMPLES, 4);
    
    // Create the GLFW window
    GLFWwindow* window = glfwCreateWindow(width, height, window_title, NULL, NULL);
    
    // Check if the window could not be created
    if (!window)
    {
        fprintf(stderr, "Failed to open GLFW window.\n");
        glfwTerminate();
        return NULL;
    }
    
    // Make the context of the window
    glfwMakeContextCurrent(window);
    
    // Set swap interval to 1
    glfwSwapInterval(1);
    
    // Call the resize callback to make sure things get drawn immediately
    Window::resize_callback(window, width, height);
    
    return window;
}

void Window::resize_callback(GLFWwindow* window, int width, int height){
    if(!switchMode){
        Window::width = width;
        Window::height = height;
    // Set the viewport size
        glViewport(0, 0, width, height);
    // Set the matrix mode to GL_PROJECTION to determine the proper camera properties
        glMatrixMode(GL_PROJECTION);
    // Load the identity matrix
        glLoadIdentity();
    // Set the perspective of the projection viewing frustum
        gluPerspective(60.0, double(width) / (double)height, 1.0, 1000.0);
    // Move camera back 20 units so that it looks at the origin (or else it's in the origin)
        glTranslatef(0, 0, -20);
    }
    else{
        current->window_width = width;
        current->window_height = height;
        delete[] current->pixels;
        current->pixels = new float[current->window_width * current->window_height * 3];
        cout << current->window_width << "and" << current->window_height << endl;

    }
}

void Window::idle_callback()
{
    // Perform any updates as necessary. Here, we will spin the cube slightly.
    //cube.update();
    current->update();
}

void Window::display_callback(GLFWwindow* window)
{
    // Clear the color and depth buffers
    if(!switchMode){
        //cout << "Entered" << endl;
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        // Set the matrix mode to GL_MODELVIEW
        glMatrixMode(GL_MODELVIEW);
        // Load the identity matrix
        glLoadIdentity();
        
        // Render objects
        //cube.draw();
        // Gets events, including input such as keyboard and mouse or window resizing
        glfwPollEvents();
        current->draw();
        
        glfwSwapBuffers(window);
    }
    else{
        
        // glDrawPixels writes a block of pixels to the framebuffer
 //       current->window_width = Window::width;
 //       current->window_height = Window:: height;
        current->clearBuffer();
        current->rasterize();
        glDrawPixels(current->window_width, current->window_height, GL_RGB, GL_FLOAT, current->pixels);
        
        // Gets events, including input such as keyboard and mouse or window resizing
        glfwPollEvents();
        // Swap buffers
        glfwSwapBuffers(window);
    }
    
    // Swap buffers
    
}


void Window::key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    // Check for a key press
    if (action == GLFW_PRESS)
    {
        //cout << "The current modifier is " << mods<< endl;
        // Check if escape was pressed
        if (key == GLFW_KEY_ESCAPE)
        {
            // Close the window. This causes the program to also terminate.
            glfwSetWindowShouldClose(window, GL_TRUE);
        }
        
        if (key == GLFW_KEY_T && mods == 1){
            switchMode = false;
            
        }
        
        else if (key == GLFW_KEY_T && mods == 0){
            switchMode = true;
        }
        
        if (key == GLFW_KEY_1){
            current = &bunny;
        }
        else if (key == GLFW_KEY_2){
            //draw the dragon
            current = &dragon;
        }
        else if (key == GLFW_KEY_3){
            //draw the dragon
            current = &bear;
            
        }
        //lowercase p decrease the size of each point
        if (key == GLFW_KEY_P && mods == 0){
            cout << "Enter 1" << endl;
            size--;
            if(size <= 0){
                cout << "ENTER" << endl;
                size = 1;
            }
            if(!switchMode){
                glPointSize(size);
            }
            else{
                
                current->pointSize = size;;
                cout << current->pointSize << endl;
            }
        }
        //uppercase p increase the size of each point
        else if (key == GLFW_KEY_P && mods == 1){
            cout << "Enter 0" << endl;
            size++;
            if(!switchMode){
                glPointSize(size);
            }
            else{
                current->pointSize = size;
                cout << current->pointSize << endl;
                
            }
        }
        //lowercase x is pressed move left;
        else if (key == GLFW_KEY_X && mods == 0){
            current->moveLeft();
            
        }
        //uppercase x is pressed move Right
        else if (key == GLFW_KEY_X && mods == 1){
            current->moveRight();
            
        }
        //lowercase z is pressed, move into the screen
        else if (key == GLFW_KEY_Z && mods == 0){
            current->moveInto();
        }
        //uppercase z is pressed, move out of the screen
        else if (key == GLFW_KEY_Z && mods == 1){
            current->moveOut();
        }
        else if (key == GLFW_KEY_Y && mods == 0){
            current->moveDown();
            
        }
        else if (key == GLFW_KEY_Y && mods == 1){
            current->moveUp();
        }
        else if (key == GLFW_KEY_S && mods == 0){
            current->scaleDown();
        }
        else if (key == GLFW_KEY_S && mods == 1){
            current->scaleUp();
        }
        else if (key == GLFW_KEY_O && mods == 0){
            current->rotateClockWise();
        }
        else if (key == GLFW_KEY_O && mods == 1){
            current->rotateCounterClockWise();
            
        }
        else if (key == GLFW_KEY_R && mods == 0){
            //cout << "enter" << endl;
            current->resetOBJ();
        }
        
    }
    
}