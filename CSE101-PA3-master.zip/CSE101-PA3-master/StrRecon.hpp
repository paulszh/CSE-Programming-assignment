// CSE 101 Winter 2016, PA 3
//
// DO NOT MODIFY

#ifndef __STR_RECON_HPP__
#define __STR_RECON_HPP__

#include <list>
#include <string>
#include <cstring>
#include <climits>
#include <map>
#include <math.h>

std::string str_recon(std::string, std::map<std::string, double>);

#endif
