// CSE 101 Winter 2016, PA 3
//
// DO NOT MODIFY

#ifndef __LCS_HPP__
#define __LCS_HPP__

#include <string>

#include "TwoD_Array.hpp"

#define MAX(x, y) (((x) > (y)) ? (x) : (y))

std::string lcs(std::string, std::string);

#endif
