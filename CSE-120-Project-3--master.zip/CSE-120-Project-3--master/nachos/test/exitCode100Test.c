#include "syscall.h"

int main() {
    exit(100);
}
