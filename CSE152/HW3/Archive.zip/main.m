% Problem 1
input_image = rgb2gray(imread('can_pix.png'));
% imshow(input_image);

result = binarization_otus(input_image);

imwrite(result,'otus.png')
% figure,imshow(result);


%Problem 2.1a
set(0, 'RecursionLimit', 1000);


find_connected_components(result);
can_cc = find_connected_components(result);
figure,imagesc(can_cc);

%Problem 2.1b
coin_image = rgb2gray(imread('coins_pix.jpg'));
coin_image = imgaussfilt(coin_image,0.18);
coin_image = binarization_otus(coin_image);
coin_image = imcomplement(imresize(coin_image, 0.245, 'bilinear'));
coin_cc = find_connected_components(coin_image);
figure,imagesc(coin_cc);
% 
% image_watch = rgb2gray(imread('watch.png'));
% binary_watch = binarization_otus(image_watch);
% % imshow(binary_watch);
% 
% watch_cc = find_connected_components(binary_watch);
% % figure,imagesc(watch_cc);

%Problem 2.2
image_mouse = rgb2gray(imread('mouse.png'));
binary_mouse = binarization_otus(image_mouse);
binary_mouse = imresize(binary_mouse, 0.9, 'bilinear');
figure,imshow(binary_mouse);
mouse_cc = find_connected_components(binary_mouse);
figure,imagesc(mouse_cc);

% Problem 2.3 calculate the moment: 

% Implement three functions(momemnt, central, normalized)
% take three images with one connected component
% For each image in your set{
%   compute centriod
%   compute eigen vectors
%   plot image
% }

% disp(moment(airpod_cc,0,0,1));
% disp(moment(binary_airpod,0,0,1));
% 
% disp(central_moment(airpod_cc,0,0,1));
% disp(central_moment(binary_airpod,0,0,1));



% CC = bwconncomp(binary_watch);
% figure,imagesc(CC);

% CC = bwconncomp(input);
% set(0, 'RecursionLimit', 1000);
% [h,w] = size(input);
% mark = ones(h,w);
% mark = -mark;
% marker = 0;