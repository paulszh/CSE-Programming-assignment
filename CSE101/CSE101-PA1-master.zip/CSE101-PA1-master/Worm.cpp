// CSE 101 Winter 2016, PA 1
//
// Name: TODO put both partners' info if applicable
// PID: TODO
// Sources of Help: TODO
// Due: 1/22/2016 at 11:59 PM

#ifndef __WORM_CPP__
#define __WORM_CPP__

#include "Graph.hpp"
#include "Worm.hpp"
#include <list>
#include <iostream>
#include <set>
#include <stack>

// include other libraries as needed
using namespace std;
void buildGraph(int n, Graph<pair<int,int>>& g){
    //map<pair<int,int>,Vertex<pair<int,int>> *>
    pair<int, int> node;
    int first,top,right;
    int upper = n*n - 1;
    //add all the neighbor to the map
    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){

            first = i * n + j;
            top  = first + n;
            right = first + 1;

            if(right < (i+1) * n){
                node = make_pair(first, right);
                if(g.vertices.count(node) == 0){
                    g.vertices[node] = new Vertex<pair<int, int>>(node);
                }

            }

            if(top <= upper){

                node = make_pair(first, top);
                if(g.vertices.count(node) == 0){
                    g.vertices[node] = new Vertex<pair<int, int>>(node);
                }

            }


        }
    }
    //construct adjacency list for each node
    list<pair<int,int>> neighbor;

    for(auto it = g.vertices.begin(); it != g.vertices.end(); ++it){

        //neighbor = it->second->edges;
        //pair<int, int> toAdd;
        int temp;
        int bound;
        if(it->first.first + 1 == it->first.second){
            //cout << "Entered +1 condition" << endl;
            temp = it->first.first + n;
            if(temp <= upper){
                (it->second->edges).push_back(make_pair(temp-n,temp));
            }
            temp = it->first.first - n;
            if(temp >= 0){
                (it->second->edges).push_back(make_pair(temp,temp+n));
            }
            temp = it->first.second + n;
            if(temp <= upper){
                (it->second->edges).push_back(make_pair(temp-n,temp));
            }
            temp = it->first.second - n;
            if(temp >= 0){
                (it->second->edges).push_back(make_pair(temp,temp+n));
            }
        }
        if(it->first.first + n == it->first.second){
            temp = it->first.first + 1;
            bound = (((it->first.first)/n)+ 1 )* n;
            if(temp < bound)
            {

                //cout << "Entered +4 condition" << endl;
                (it->second->edges).push_back(make_pair(temp-1,temp));
            }

            temp = it->first.first - 1;
            bound = (temp+1) - ((temp+1)% n);
            if(temp >= bound ){
                (it->second->edges).push_back(make_pair(temp,temp+1));
            }

            temp = it->first.second + 1;
            bound = (((it->first.second)/n)+ 1)* n;
            if(temp < bound){
                //cout << "Entered +4 condition" << endl;
                (it->second->edges).push_back(make_pair(temp-1,temp));
            }

            temp = it->first.second - 1;
            bound = (temp+1) - ((temp+1)% n);
            if(temp >= bound){
                (it->second->edges).push_back(make_pair(temp,temp+1));
            }
        }

    }
}






bool canReachBed(int n, int s1, int s2, int d1, int d2, std::list<int> o) {
    // TODO
    Graph<pair<int,int>> g;
    buildGraph(n,g);

    set<pair<int, int>> visited;
    stack<pair<int, int>> stk;  // stack to store the pointer of vertex
    list<pair<int, int>> neighbor;
    //map<pair<int, int>, Vertex<int,int> *> Gmap;
    Vertex<pair<int, int>> * curr;
    pair<int,int> id;
    int order = 1;
    list<pair<int,int>> adj;

    //Gmap = g.vertices;
    for( auto it = g.vertices.begin(); it != g.vertices.end(); ++it){
        it->second->visited = false;//set all the visited to false
        it->second->pre = 0;//set all the pre to 0
        it->second->post = 0;//set all the post to 0
    }
    for(auto itera = o.begin(); itera != o.end(); ++itera){
        if(s1 ==  (*itera) || s2 == (*itera) || d1 == (*itera) || d2 == (*itera)){
            return false;
        }
        for(auto iterat = g.vertices.begin(); iterat != g.vertices.end(); ++ iterat){
            if(iterat->first.first == (*itera)||iterat->first.second == (*itera)){
                iterat->second->visited = true;
            }
        }
    }

    stk.push(make_pair(s1,s2));  //push the start vertex to the stack
    while(!stk.empty()){// while the stack is not empty
        id = stk.top();
        //cout << "current id" << id.first << " " << id.second << endl;
        //cout << ite->first.first << " " << ite->first.second << "   ";
        for(auto iterator = adj.begin();iterator != adj.end(); ++iterator){
            //cout << "enter" <<endl;
            cout << iterator->first << " " << iterator->second << "|";
        }


        //________
        curr = g.vertices.find(id)->second;
        //cout << "segfault" << endl;
        neighbor = curr->edges;
        //cout << "segfault1" << endl;

        if(curr->pre > 0){ //post visit the current node
            stk.pop();
            curr->post = order;
            order++;
        }

        else{                   //pre visit the node and add its neighbor
            visited.insert(id);
            curr->visited = true;
            curr->pre = order;
            order++;

            for(auto it = neighbor.begin(); it != neighbor.end(); ++it){
                if(!(g.vertices.find(*it)->second->visited)){
                            stk.push(*it);
                }

            }
        }
    }
    /*
    //JUST FOR TEST
    cout << " "<< endl;
    for(auto ite = g.vertices.begin(); ite != g.vertices.end(); ++ite){
        adj = ite->second->edges;
        cout << ite->first.first << " " << ite->first.second << "   ";
        for(auto iterator = adj.begin();iterator != adj.end(); ++iterator){
            //cout << "enter" <<endl;
            cout << iterator->first << " " << iterator->second << "|";
        }
        cout << " "<< endl;
    }
    //cout << "reached" << endl;
    */
    for(auto iter = visited.begin(); iter != visited.end(); ++iter){
        if((iter->first == d1 && iter->second== d2) || (iter->first== d2 && iter->second== d1)){
            return true;
        }
    }
    return false;




}
#endif
