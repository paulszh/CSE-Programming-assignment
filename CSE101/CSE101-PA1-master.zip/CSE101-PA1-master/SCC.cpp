// CSE 101 Winter 2016, PA 1
//
// Name: ZHOUHANG SHAO put both partners' info if applicable
// PID: A99086018
// Sources of Help: TODO
// Due: 1/22/2016 at 11:59 PM

#ifndef __SCC_CPP__
#define __SCC_CPP__

#include "Graph.hpp"
#include <list>
#include <set>
#include <stack>
#include <iostream>
// include more libraries as needed
using namespace std;

template <class T>
list<std::set<T> > scc(Graph<T>& g){
    list<set<T>> SCCS;
    list<T> adj;
    Vertex<T> * current;
    map<T, Vertex<T> *> reverseG = reverseGraph(g);
    list<T> topOrder;
    stack<T> stk;  // stack to store the pointer of vertex
    list<T> neighbor;
    Vertex<T> * curr;
    T id;
    int order = 1;

    for( auto it = reverseG.begin(); it != reverseG.end(); ++it){
        it->second->visited = false;//set all the visited to false
        it->second->pre = 0;//set all the pre to 0
        it->second->post = 0;//set all the post to 0
    }

    while(topOrder.size() < reverseG.size()){
        for(auto it = reverseG.begin(); it != reverseG.end(); ++it){
            if(!(it->second->visited)){
                stk.push(it->first);
                break;
            }
        }
        while(!stk.empty()){// while the stack is not empty
            id = stk.top();
            curr = reverseG.find(id)->second;
            neighbor = curr->edges;

            if(curr->pre > 0){ //post visit the current node
                stk.pop();
                curr->post = order;
                topOrder.push_front(id);
                order++;
            }

            else{                   //pre visit the node and add its neighbor
                curr->visited = true;
                curr->pre = order;
                order++;

                for(auto it = neighbor.begin(); it != neighbor.end(); ++it){
                    if(!(reverseG.find(*it)->second->visited)){
                        stk.push(*it);
                    }
                }

            }
        }
    }
    stack<T> myStack;
    set<T> visited;

    for( auto it = g.vertices.begin(); it != g.vertices.end(); ++it){
        it->second->visited = false;//set all the visited to false
        it->second->pre = 0;//set all the pre to 0
        it->second->post = 0;//set all the post to 0
    }


    for(auto itera = topOrder.begin(); itera != topOrder.end(); ++itera){

        if(!(g.vertices.find(*itera)->second->visited)){
            myStack.push(*itera);  //push the start vertex to the stack
            visited.insert(*itera);
        }

        while(!myStack.empty()){// while the stack is not empty
            id = myStack.top();
            curr = g.vertices.find(id)->second;
            neighbor = curr->edges;

            if(curr->pre > 0){ //post visit the current node
                myStack.pop();
                curr->post = order;
                order++;
            }

            else{                   //pre visit the node and add its neighbor
                visited.insert(id);
                curr->visited = true;
                curr->pre = order;
                order++;

                for(auto iterato = neighbor.begin(); iterato != neighbor.end(); ++iterato){
                    if(!(g.vertices.find(*iterato)->second->visited)){
                        myStack.push(*iterato);
                    }
                }

            }
        }
        if(!visited.empty()){
            SCCS.push_back(visited);
        }
        visited.clear();
    }
    return SCCS;
}

template <class T>
map<T, Vertex<T> *> reverseGraph(Graph<T> & g){

    list<T> adjList;
    map<T, Vertex<T> *> reverse;
    Vertex<T> * toInsert;
    T v1;
    T v2;
    //copy all the node from the original graph
    for(auto it = g.vertices.begin(); it != g.vertices.end(); ++it){

        //cout << "Enter outer for loop" << endl;
        v1 = g.vertices.find(it->first)->first;
        toInsert = g.vertices.find(it->first)->second;
        adjList = toInsert->edges;

        for(auto iter = adjList.begin(); iter != adjList.end(); ++iter){
            //cout << "Enter inner for loop" << endl;
            v2 = *iter;
            if (reverse.count(v1) == 0) {
                reverse[v1] = new Vertex<T>(v1);
            }
            if (reverse.count(v2) == 0) {
                reverse[v2] = new Vertex<T>(v2);
            }
            reverse[v2]->edges.push_back(v1);
        }
    }
    return reverse;
}
#endif
