// CSE 101 Winter 2016, PA 1
//
// Name: Zhouhang Shao
// PID: A99086016
// Sources of Help: TODO
// Due: 1/22/2016 at 11:59 PM

#ifndef __TOP_ORDER_CPP__
#define __TOP_ORDER_CPP__

#include "Graph.hpp"
#include <list>
#include <stack>
#include <iostream>
// include more libraries as needed
using namespace std;

template <class T>
list<T> top_order(Graph<T>& g) {
    list<T> topOrder;
    stack<T> stk;  // stack to store the pointer of vertex
    list<T> neighbor;
    map<T, Vertex<T> *> Gmap;
    Vertex<T> * curr;
    T id;
    int order = 1;

    Gmap = g.vertices;
    for( auto it = Gmap.begin(); it != Gmap.end(); ++it){
        it->second->visited = false;//set all the visited to false
        it->second->pre = 0;//set all the pre to 0
        it->second->post = 0;//set all the post to 0
    }

    while(topOrder.size() < g.vertices.size()){
        for(auto it = g.vertices.begin(); it != g.vertices.end(); ++it){
            if(!(it->second->visited)){
                stk.push(it->first);
                break;
            }
        }
        while(!stk.empty()){// while the stack is not empty
            id = stk.top();
            curr = Gmap.find(id)->second;
            neighbor = curr->edges;

            if(curr->pre > 0){ //post visit the current node
                stk.pop();
                curr->post = order;
                topOrder.push_front(id);
                order++;
            }

            else{                   //pre visit the node and add its neighbor
                curr->visited = true;
                curr->pre = order;
                order++;

                for(auto it = neighbor.begin(); it != neighbor.end(); ++it){
                    if(!(Gmap.find(*it)->second->visited)){
                        stk.push(*it);
                    }
                    else{
                        if(Gmap.find(*it)->second->post == 0){//cycle is found
                            topOrder.clear();
                            return topOrder;
                        }
                    }
                }

            }
        }
    }
    return topOrder;
}

#endif
