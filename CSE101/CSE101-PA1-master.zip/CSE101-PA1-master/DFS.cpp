// CSE 101 Winter 2016, PA 1
//
// Name: Zhouhang Shao put both partners' info if applicable
// PID: A99086018
// Sources of Help: TODO
// Due: 1/22/2016 at 11:59 PM

#ifndef __DFS_CPP__
#define __DFS_CPP__

#include "Graph.hpp"
#include <set>
#include <stack>
#include <map>
#include <iostream>

// include more libraries as needed
using namespace std;

template <class T>
set<T> dfs(Graph<T>& g, T t){
    set<T> visited;
    stack<T> stk;  // stack to store the pointer of vertex
    list<T> neighbor;
    map<T, Vertex<T> *> Gmap;
    Vertex<T> * curr;
    T id;
    int order = 1;

    Gmap = g.vertices;
    for( auto it = Gmap.begin(); it != Gmap.end(); ++it){
        it->second->visited = false;//set all the visited to false
        it->second->pre = 0;//set all the pre to 0
        it->second->post = 0;//set all the post to 0
    }

    stk.push(t);  //push the start vertex to the stack

    while(!stk.empty()){// while the stack is not empty
        id = stk.top();
        curr = Gmap.find(id)->second;
        neighbor = curr->edges;

        if(curr->pre > 0){ //post visit the current node
            stk.pop();
            curr->post = order;
            order++;
        }

        else{                   //pre visit the node and add its neighbor
            visited.insert(id);
            curr->visited = true;
            curr->pre = order;
            order++;

            for(auto it = neighbor.begin(); it != neighbor.end(); ++it){
                if(!(Gmap.find(*it)->second->visited)){
                    stk.push(*it);
                }
            }

        }
    }
    /*for(auto it = g.vertices.begin(); it != g.vertices.end(); it++){
        cout << it->second->id << " " << it->second->pre << " " <<it->second->post << endl;
    }*/

    return visited;
}


#endif
