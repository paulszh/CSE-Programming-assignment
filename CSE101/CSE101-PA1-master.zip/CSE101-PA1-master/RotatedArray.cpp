// CSE 101 Winter 2016, PA 1
//
// Name: ZHOUHANG SHAO put both partners' info if applicable
// PID: A990866018
// Sources of Help: leetCode
// Due: 1/22/2016 at 11:59 PM

#include <iostream>
#include <chrono>
#include <list>
#include <stdlib.h>

// you can change SIZE to vary the size of array
#define SIZE 10000
using namespace std;

// returns the index of the element found in the list
int naive_search(int * list, int e) {
    // TODO implement naive search
    for(unsigned int i = 0; i < SIZE; i++){
        //cout  << *(list + i) << endl;
        if(*(list + i) == e ){
            //cout << "the index " << i <<endl;
            //cout << "e " << e <<endl;
            return i;
        }
    }
    return -1;
}

// returns the index of the found element
int DQ_search(int * list, int e) {
    // TODO implement DQ search
    // you may want to implement a recursive helper method
    int low = 0;
    int high = SIZE - 1;
    int mid;
    //Find the index of the smallest element
    while(low < high){
        mid = (low + high)/2;
        if(*(list + mid) > *(list + high)){
            low = mid + 1;
        }
        else{
            high = mid;
        }
    }

    int start = low;
    low = 0;
    high = SIZE-1;

    //Binary search the entire array
    while(low <= high){
        mid = (low + high)/2;
        int pivot = (mid + start)%SIZE;
        if(*(list + pivot) == e ){
            //cout << "pivot" << pivot <<endl;
            return pivot;
        }
        if(*(list + pivot) < e){
            low = mid + 1;
        }
        else{
            high = mid - 1;
        }
    }

    return -2;
}

// This main is already fully implemented. However, you are free
// to modify it if you feel necessary (i.e. running multiple queries
// for larger array sizes instead of running one query per run)
int main(int argc, char * argv[]) {
    std::cout << "Running Rotated Sorted Array with size: " << SIZE << std::endl;
    int * arr = new int[SIZE];

    // build the rotated array using the random rotation point
    srand(time(0));
    int rotation = rand() % SIZE;
    for (int i = 0; i < SIZE; ++i) {
        arr[i] = (i + rotation) % SIZE + 1;
    }

    //srand(time(0));
    int target = rand() % SIZE + 1;

    // time the naive approach
    auto begin = std::chrono::high_resolution_clock::now();

    int loc_naive = naive_search(arr, target);

    auto end = std::chrono::high_resolution_clock::now();

    int elapsed_time = std::chrono::duration_cast<std::chrono::milliseconds>(end-begin).count();

    std::cout << "Time for Naive Search: " << elapsed_time << "ms" << std::endl;

    // time the DQ approach
    begin = std::chrono::high_resolution_clock::now();

    int loc_DQ = DQ_search(arr, target);

    end = std::chrono::high_resolution_clock::now();

    elapsed_time = std::chrono::duration_cast<std::chrono::milliseconds>(end-begin).count();

    std::cout << "Time for DQ Search: " << elapsed_time << "ms" << std::endl;

    if (loc_naive != loc_DQ) {
        std::cout << "ERROR, indicies returned by naive and DQ do not match." << std::endl;
    }

    delete arr;
    return 0;
}
