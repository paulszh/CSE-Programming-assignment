inputImage  = imread('lena512.tif');

image = double(inputImage);
[r1,c1] = size(image);
trainSet = reshape(image, r1*c1, 1);

i = 7;
[partition, codebook] = lloyds(trainSet, 2^i);


newPartition = zeros(2^i + 1, 1);
newpartition(2:2^i) = partition(1:2^i-1);
newPartition(1) = 0;
newPartition(2^i+1) = 255;

for i = 1 : r1
    for j = 1 : c1
         pixelIntensity = image(r,c);
         for k = 1 : 2^i + 1
             if(pixelIntensity >= newPartition(1:i))
             
    end
end

Lloyds = imquantize(image, partition, codebook);